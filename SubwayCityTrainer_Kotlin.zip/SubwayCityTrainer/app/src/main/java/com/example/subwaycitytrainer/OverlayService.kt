package com.example.subwaycitytrainer

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.view.WindowManager.LayoutParams

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var runCount = 0
    private var timerVisible = true
    private var statsVisible = true

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(28, 31, 43))
        }

        val header = TextView(this).apply {
            text = "SUBWAY TRAINER   ⋮"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
        }
        val timer = TextView(this).apply {
            text = "Тренировка: таймер включён"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        val stats = TextView(this).apply {
            text = "Забеги: $runCount"
            setTextColor(Color.WHITE)
            textSize = 14f
        }

        val timerButton = Button(this).apply {
            text = "Вкл/выкл таймер"
            setOnClickListener {
                timerVisible = !timerVisible
                timer.text = if (timerVisible) "Тренировка: таймер включён" else "Тренировка: таймер выключен"
            }
        }
        val countButton = Button(this).apply {
            text = "Новый забег (+1)"
            setOnClickListener {
                runCount++
                stats.text = "Забеги: $runCount"
            }
        }
        val statsButton = Button(this).apply {
            text = "Показать/скрыть счётчик"
            setOnClickListener {
                statsVisible = !statsVisible
                stats.visibility = if (statsVisible) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
        val closeButton = Button(this).apply {
            text = "Закрыть панель"
            setOnClickListener { stopSelf() }
        }

        root.addView(header)
        root.addView(timer)
        root.addView(timerButton)
        root.addView(stats)
        root.addView(countButton)
        root.addView(statsButton)
        root.addView(closeButton)

        val params = LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 160
        }

        panel = root
        windowManager.addView(root, params)
    }

    override fun onDestroy() {
        panel?.let { windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
