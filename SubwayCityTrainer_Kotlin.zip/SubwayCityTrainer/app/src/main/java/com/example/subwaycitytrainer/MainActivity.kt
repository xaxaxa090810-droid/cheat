package com.example.subwaycitytrainer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }

        val title = TextView(this).apply {
            text = "SUBWAY CITY TRAINER"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Внешняя панель-помощник для тренировок.\nНе изменяет файлы или память игры."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val permissionButton = Button(this).apply {
            text = "Разрешить показ поверх приложений"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val startButton = Button(this).apply {
            text = "Запустить плавающую панель"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Панель запущена", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Сначала разреши показ поверх приложений", Toast.LENGTH_LONG).show()
                }
            }
        }
        val stopButton = Button(this).apply {
            text = "Остановить панель"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(permissionButton)
        layout.addView(startButton)
        layout.addView(stopButton)
        setContentView(layout)
    }
}
